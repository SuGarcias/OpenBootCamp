def bisiesto(year):
    year = int(year)
    if year%4 == 0 and year%100 != 0 and year%400!=0 :
        return True
    elif year%4 == 0 and year%100 == 0 and year%400==0 :
        return True
    else: return False   

año = input('Introduce un año y te digo si es bisiesto: ')  

if bisiesto(año) == True:
    print('Efectivamente, año bisiesto')
else: print('Este año no es bisiesto')

