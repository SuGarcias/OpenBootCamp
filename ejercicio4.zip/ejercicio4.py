valor = 100
while valor >= 1:
    print(valor)
    valor -= 1
    
